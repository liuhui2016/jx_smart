/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50505
Source Host           : 113.106.93.195:3366
Source Database       : jxdb

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-03-09 10:33:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for acc_authority
-- ----------------------------
DROP TABLE IF EXISTS `acc_authority`;
CREATE TABLE `acc_authority` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `is_menu` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `position` double NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `menu_img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKECFE8D05D5C21891` (`resource_id`) USING BTREE,
  KEY `FKECFE8D0542F3215C` (`parent_id`) USING BTREE,
  KEY `FKECFE8D05B1658BB7` (`resource_id`) USING BTREE,
  KEY `FKECFE8D05DBBE12F6` (`parent_id`) USING BTREE,
  CONSTRAINT `acc_authority_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `acc_resource` (`id`),
  CONSTRAINT `acc_authority_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `acc_authority` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1038 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_authority_resource
-- ----------------------------
DROP TABLE IF EXISTS `acc_authority_resource`;
CREATE TABLE `acc_authority_resource` (
  `authority_id` bigint(20) NOT NULL,
  `resource_id` bigint(20) NOT NULL,
  PRIMARY KEY (`authority_id`,`resource_id`),
  KEY `FKFA903E08FE66F023` (`authority_id`) USING BTREE,
  KEY `FKFA903E08D5C21891` (`resource_id`) USING BTREE,
  KEY `FKFA903E089731E1BD` (`authority_id`) USING BTREE,
  KEY `FKFA903E08B1658BB7` (`resource_id`) USING BTREE,
  CONSTRAINT `acc_authority_resource_ibfk_1` FOREIGN KEY (`authority_id`) REFERENCES `acc_authority` (`id`),
  CONSTRAINT `acc_authority_resource_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `acc_resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_custom_menu
-- ----------------------------
DROP TABLE IF EXISTS `acc_custom_menu`;
CREATE TABLE `acc_custom_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `authority_id` bigint(20) DEFAULT NULL,
  `position` double NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1289DEAF220AC6B2` (`user_id`) USING BTREE,
  KEY `FK1289DEAF6B7FE102` (`authority_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_domain
-- ----------------------------
DROP TABLE IF EXISTS `acc_domain`;
CREATE TABLE `acc_domain` (
  `dtype` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `auto_code` bigint(20) DEFAULT NULL,
  `base` bit(1) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `manager` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `position` double NOT NULL,
  `report_name` varchar(255) DEFAULT NULL,
  `sharing` bit(1) NOT NULL,
  `short_name` varchar(255) DEFAULT NULL,
  `state` bit(1) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`) USING BTREE,
  KEY `FK64C2F642DCDEC8EB` (`parent_id`) USING BTREE,
  KEY `FK64C2F64274F0CD91` (`parent_id`) USING BTREE,
  CONSTRAINT `acc_domain_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `acc_domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_group
-- ----------------------------
DROP TABLE IF EXISTS `acc_group`;
CREATE TABLE `acc_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_group_role
-- ----------------------------
DROP TABLE IF EXISTS `acc_group_role`;
CREATE TABLE `acc_group_role` (
  `group_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  KEY `FK58B6ACB43CE24311` (`role_id`) USING BTREE,
  KEY `FK58B6ACB48CD9E323` (`group_id`) USING BTREE,
  KEY `FK58B6ACB476D93937` (`role_id`) USING BTREE,
  KEY `FK58B6ACB491C1B1BD` (`group_id`) USING BTREE,
  CONSTRAINT `acc_group_role_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `acc_role` (`id`),
  CONSTRAINT `acc_group_role_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `acc_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_group_user
-- ----------------------------
DROP TABLE IF EXISTS `acc_group_user`;
CREATE TABLE `acc_group_user` (
  `group_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  KEY `FK58B81809E20D06F1` (`user_id`) USING BTREE,
  KEY `FK58B818098CD9E323` (`group_id`) USING BTREE,
  KEY `FK58B818091C03FD17` (`user_id`) USING BTREE,
  KEY `FK58B8180991C1B1BD` (`group_id`) USING BTREE,
  CONSTRAINT `acc_group_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `acc_user` (`id`),
  CONSTRAINT `acc_group_user_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `acc_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_resource
-- ----------------------------
DROP TABLE IF EXISTS `acc_resource`;
CREATE TABLE `acc_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `res_string` varchar(255) DEFAULT NULL,
  `res_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `res_string` (`res_string`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=799 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_role
-- ----------------------------
DROP TABLE IF EXISTS `acc_role`;
CREATE TABLE `acc_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_role_authority
-- ----------------------------
DROP TABLE IF EXISTS `acc_role_authority`;
CREATE TABLE `acc_role_authority` (
  `role_id` bigint(20) NOT NULL,
  `authority_id` bigint(20) NOT NULL,
  KEY `FK3CC1AA383CE24311` (`role_id`) USING BTREE,
  KEY `FK3CC1AA38FE66F023` (`authority_id`) USING BTREE,
  KEY `FK3CC1AA3876D93937` (`role_id`) USING BTREE,
  KEY `FK3CC1AA389731E1BD` (`authority_id`) USING BTREE,
  CONSTRAINT `acc_role_authority_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `acc_role` (`id`),
  CONSTRAINT `acc_role_authority_ibfk_2` FOREIGN KEY (`authority_id`) REFERENCES `acc_authority` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_user
-- ----------------------------
DROP TABLE IF EXISTS `acc_user`;
CREATE TABLE `acc_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `account_expired` bit(1) NOT NULL,
  `account_locked` bit(1) NOT NULL,
  `credentials_expired` bit(1) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `account_enabled` bit(1) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `real_name` varchar(50) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `domain_id` bigint(20) DEFAULT NULL,
  `birth_date` datetime DEFAULT NULL,
  `certificate_no` varchar(255) DEFAULT NULL,
  `entry_date` datetime DEFAULT NULL,
  `id_no` varchar(255) DEFAULT NULL,
  `id_type` varchar(255) DEFAULT NULL,
  `married` bit(1) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `start_work_date` datetime DEFAULT NULL,
  `cuscode` varchar(255) DEFAULT NULL,
  `custom_id` varchar(255) DEFAULT NULL,
  `user_group` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE,
  KEY `FK7FBC54C9885E4E91` (`domain_id`) USING BTREE,
  KEY `FK7FBC54C920705337` (`domain_id`) USING BTREE,
  CONSTRAINT `acc_user_ibfk_1` FOREIGN KEY (`domain_id`) REFERENCES `acc_domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_user_role_grant
-- ----------------------------
DROP TABLE IF EXISTS `acc_user_role_grant`;
CREATE TABLE `acc_user_role_grant` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  KEY `FK94924D493CE24311` (`role_id`) USING BTREE,
  KEY `FK94924D49E20D06F1` (`user_id`) USING BTREE,
  KEY `FK94924D4976D93937` (`role_id`) USING BTREE,
  KEY `FK94924D491C03FD17` (`user_id`) USING BTREE,
  CONSTRAINT `acc_user_role_grant_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `acc_user` (`id`),
  CONSTRAINT `acc_user_role_grant_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `acc_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for acc_user_role_use
-- ----------------------------
DROP TABLE IF EXISTS `acc_user_role_use`;
CREATE TABLE `acc_user_role_use` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  KEY `FK501278F43CE24311` (`role_id`) USING BTREE,
  KEY `FK501278F4E20D06F1` (`user_id`) USING BTREE,
  KEY `FK501278F476D93937` (`role_id`) USING BTREE,
  KEY `FK501278F41C03FD17` (`user_id`) USING BTREE,
  CONSTRAINT `acc_user_role_use_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `acc_user` (`id`),
  CONSTRAINT `acc_user_role_use_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `acc_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for browser_customer
-- ----------------------------
DROP TABLE IF EXISTS `browser_customer`;
CREATE TABLE `browser_customer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `begintime` varchar(255) DEFAULT NULL,
  `cdesc` varchar(255) DEFAULT NULL,
  `citys` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `devicecount` int(11) DEFAULT NULL,
  `deviceday` int(11) DEFAULT NULL,
  `endtime` varchar(255) DEFAULT NULL,
  `openrate` int(11) DEFAULT NULL,
  `passdevice` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `unitprice` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cityadmincode
-- ----------------------------
DROP TABLE IF EXISTS `cityadmincode`;
CREATE TABLE `cityadmincode` (
  `city_code` int(6) DEFAULT NULL,
  `level` int(1) DEFAULT NULL COMMENT '1:省,2:市,3:区县',
  `province` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `county` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_city
-- ----------------------------
DROP TABLE IF EXISTS `common_city`;
CREATE TABLE `common_city` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `pid` bigint(20) DEFAULT NULL,
  `pinyin` varchar(50) DEFAULT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `continent` smallint(6) DEFAULT NULL COMMENT '所属洲',
  `code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_city_continent
-- ----------------------------
DROP TABLE IF EXISTS `common_city_continent`;
CREATE TABLE `common_city_continent` (
  `id` smallint(6) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_custom
-- ----------------------------
DROP TABLE IF EXISTS `common_custom`;
CREATE TABLE `common_custom` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `connectname` varchar(255) DEFAULT NULL,
  `createtime` varchar(255) DEFAULT NULL,
  `customid` varchar(255) DEFAULT NULL,
  `isdefault` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_lang
-- ----------------------------
DROP TABLE IF EXISTS `common_lang`;
CREATE TABLE `common_lang` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createtime` varchar(255) DEFAULT NULL,
  `lang` varchar(255) DEFAULT NULL,
  `langdesc` varchar(255) DEFAULT NULL,
  `simplified` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_log_city_undefine
-- ----------------------------
DROP TABLE IF EXISTS `common_log_city_undefine`;
CREATE TABLE `common_log_city_undefine` (
  `id` bigint(20) NOT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_picr
-- ----------------------------
DROP TABLE IF EXISTS `common_picr`;
CREATE TABLE `common_picr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `pic_md5` varchar(255) DEFAULT NULL,
  `pic_path` varchar(255) DEFAULT NULL,
  `pic_url` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_province
-- ----------------------------
DROP TABLE IF EXISTS `common_province`;
CREATE TABLE `common_province` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `pinyin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for common_resolution
-- ----------------------------
DROP TABLE IF EXISTS `common_resolution`;
CREATE TABLE `common_resolution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `height` int(11) DEFAULT NULL,
  `isshow` int(11) DEFAULT NULL,
  `resolution` varchar(20) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_address
-- ----------------------------
DROP TABLE IF EXISTS `jx_address`;
CREATE TABLE `jx_address` (
  `adr_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '地址id',
  `u_id` bigint(20) NOT NULL COMMENT '用户id',
  `adr_name` varchar(50) DEFAULT NULL COMMENT '收货人',
  `adr_phone` varchar(20) DEFAULT NULL COMMENT '收货人手机号',
  `adr_area` varchar(100) DEFAULT NULL COMMENT '地区',
  `adr_detail` varchar(300) DEFAULT NULL COMMENT '详细地址',
  `adr_code` bigint(20) DEFAULT NULL COMMENT '邮政编码',
  `adr_first` int(11) DEFAULT NULL COMMENT '等于0时为默认收货地址',
  `adr_addtime` datetime DEFAULT NULL COMMENT '新增时间',
  `adr_modtime` datetime DEFAULT NULL COMMENT '修改时间',
  `adr_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`adr_id`),
  KEY `fk_reference_2` (`u_id`) USING BTREE,
  KEY `IDX_UID` (`u_id`),
  CONSTRAINT `jx_address_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `jx_user` (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='地址表';

-- ----------------------------
-- Table structure for jx_addsellnum
-- ----------------------------
DROP TABLE IF EXISTS `jx_addsellnum`;
CREATE TABLE `jx_addsellnum` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '合伙人id',
  `par_no` bigint(20) DEFAULT NULL,
  `par_name` varchar(50) DEFAULT NULL COMMENT '合伙人名字',
  `par_level` varchar(20) DEFAULT NULL COMMENT '合伙人级别',
  `par_parentid` bigint(20) DEFAULT NULL COMMENT '上级合伙人id',
  `par_parent` varchar(50) DEFAULT NULL COMMENT '上级合伙人',
  `par_area` varchar(100) DEFAULT NULL COMMENT '合伙人所在地区',
  `par_address` varchar(200) DEFAULT NULL COMMENT '联系地址',
  `par_phone` varchar(20) DEFAULT NULL COMMENT '联系人电话',
  `par_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  `par_sellernum` bigint(20) DEFAULT NULL COMMENT '合伙人销售设备的总台数',
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44030400001922 DEFAULT CHARSET=utf8 COMMENT='合伙人表';

-- ----------------------------
-- Table structure for jx_advpic
-- ----------------------------
DROP TABLE IF EXISTS `jx_advpic`;
CREATE TABLE `jx_advpic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '广告图片id',
  `adv_phone` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `adv_imgurl` varchar(300) DEFAULT NULL,
  `adv_dir` varchar(100) DEFAULT NULL COMMENT '图片目录',
  `adv_name` varchar(50) DEFAULT NULL COMMENT '图片名称',
  `adv_type` bigint(20) NOT NULL COMMENT '广告图片类型',
  `adv_vaildtime` timestamp NULL DEFAULT NULL COMMENT '广告有效时间',
  `adv_invildtime` timestamp NULL DEFAULT NULL COMMENT '广告失效时间',
  `adv_addtime` datetime DEFAULT NULL COMMENT '图片添加时间',
  `adv_modtime` datetime DEFAULT NULL COMMENT '图片修改时间',
  `adv_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  `adv_url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PHONE` (`adv_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='广告图片表';

-- ----------------------------
-- Table structure for jx_code
-- ----------------------------
DROP TABLE IF EXISTS `jx_code`;
CREATE TABLE `jx_code` (
  `code_no` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '码表代号',
  `code_value` bigint(20) NOT NULL COMMENT '码表值',
  `code_name` varchar(100) DEFAULT NULL COMMENT '码表名称',
  `code_type` varchar(100) DEFAULT NULL COMMENT '码值类型',
  `code_fileurl` varchar(300) DEFAULT NULL COMMENT '储存文件类',
  `code_value1` varchar(200) DEFAULT NULL COMMENT '码表值1',
  `code_name1` varchar(200) DEFAULT NULL COMMENT '码表值名称',
  `code_order` varchar(200) DEFAULT NULL COMMENT '排序字段',
  `code_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`code_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='码表信息表';

-- ----------------------------
-- Table structure for jx_family
-- ----------------------------
DROP TABLE IF EXISTS `jx_family`;
CREATE TABLE `jx_family` (
  `fam_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '家庭id',
  `fam_owner` bigint(20) NOT NULL,
  PRIMARY KEY (`fam_id`),
  KEY `IDX_FID` (`fam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1488883735136848838 DEFAULT CHARSET=utf8 COMMENT='家庭群组表';

-- ----------------------------
-- Table structure for jx_fampro
-- ----------------------------
DROP TABLE IF EXISTS `jx_fampro`;
CREATE TABLE `jx_fampro` (
  `fam_id` bigint(20) NOT NULL COMMENT '家庭id',
  `pro_id` bigint(20) NOT NULL COMMENT '产品id',
  PRIMARY KEY (`fam_id`,`pro_id`),
  KEY `fk_reference_8` (`fam_id`) USING BTREE,
  KEY `fk_reference_9` (`pro_id`) USING BTREE,
  KEY `IDX_FID` (`fam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='家庭产品表';

-- ----------------------------
-- Table structure for jx_famuser
-- ----------------------------
DROP TABLE IF EXISTS `jx_famuser`;
CREATE TABLE `jx_famuser` (
  `fam_id` bigint(20) NOT NULL COMMENT '家庭id',
  `u_id` bigint(20) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`fam_id`,`u_id`),
  KEY `fk_reference_6` (`fam_id`) USING BTREE,
  KEY `fk_reference_7` (`u_id`) USING BTREE,
  KEY `IDX_FID` (`fam_id`),
  CONSTRAINT `jx_famuser_ibfk_1` FOREIGN KEY (`fam_id`) REFERENCES `jx_family` (`fam_id`),
  CONSTRAINT `jx_famuser_ibfk_2` FOREIGN KEY (`u_id`) REFERENCES `jx_user` (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='家庭用户表';

-- ----------------------------
-- Table structure for jx_filter_warning
-- ----------------------------
DROP TABLE IF EXISTS `jx_filter_warning`;
CREATE TABLE `jx_filter_warning` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `order_no` varchar(15) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_phone` varchar(15) DEFAULT NULL,
  `pro_no` varchar(36) DEFAULT NULL,
  `filter_name` varchar(20) DEFAULT NULL,
  `time_left` int(3) DEFAULT NULL,
  `manager_no` bigint(20) DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  `create_time` date DEFAULT NULL,
  `modify_time` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ORDERNO` (`order_no`,`user_phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_menu
-- ----------------------------
DROP TABLE IF EXISTS `jx_menu`;
CREATE TABLE `jx_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '模块id',
  `menu_name` varchar(100) DEFAULT NULL COMMENT '模块名称',
  `menu_parentid` bigint(20) DEFAULT NULL COMMENT '上级模块id',
  `menu_icourl` varchar(300) DEFAULT NULL COMMENT '模块ico',
  `menu_addtime` datetime DEFAULT NULL COMMENT '模块新增时间',
  `menu_modtime` datetime DEFAULT NULL COMMENT '模块修改时间',
  `menu_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `IDX_NAME` (`menu_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_messages
-- ----------------------------
DROP TABLE IF EXISTS `jx_messages`;
CREATE TABLE `jx_messages` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '0代表订单到期,1代表交易,2代表绑定,3代表分享',
  `u_id` bigint(20) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `content` varchar(300) DEFAULT NULL,
  `nextparams` varchar(255) DEFAULT NULL,
  `isread` int(11) DEFAULT '0' COMMENT '0代表未读 1代表已读',
  `message_time` varchar(100) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '0代表订单到期提醒,1支付成功,2绑定成功,3分享成功',
  PRIMARY KEY (`id`),
  KEY `IDX_UID` (`u_id`),
  KEY `IDX_PARAMS` (`nextparams`)
) ENGINE=InnoDB AUTO_INCREMENT=258 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_opinon
-- ----------------------------
DROP TABLE IF EXISTS `jx_opinon`;
CREATE TABLE `jx_opinon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '意见id',
  `op_phone` varchar(20) DEFAULT NULL COMMENT '反馈人联系手机号码',
  `op_user` varchar(50) DEFAULT NULL COMMENT '反馈人',
  `op_titel` varchar(100) DEFAULT NULL COMMENT '反馈主题',
  `op_detail` varchar(1000) DEFAULT NULL COMMENT '反馈内容',
  `op_addtime` datetime DEFAULT NULL COMMENT '反馈时间',
  `op_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  `op_modtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_USER` (`op_user`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COMMENT='意见反馈表';

-- ----------------------------
-- Table structure for jx_order
-- ----------------------------
DROP TABLE IF EXISTS `jx_order`;
CREATE TABLE `jx_order` (
  `ord_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '订单id',
  `ord_no` varchar(100) NOT NULL COMMENT '订单号 ',
  `u_id` bigint(20) NOT NULL COMMENT '客户id',
  `adr_id` varchar(200) DEFAULT NULL,
  `pro_id` bigint(20) DEFAULT NULL COMMENT '产品ID',
  `pro_no` varchar(100) DEFAULT NULL COMMENT '产品no',
  `ord_way` int(20) DEFAULT '0',
  `ord_protypeid` bigint(20) DEFAULT NULL COMMENT '产品商品名称，0=包年包流量；1=按流量付费',
  `ord_price` float(100,2) DEFAULT NULL COMMENT '订单价格',
  `ord_managerno` varchar(50) DEFAULT NULL COMMENT '产品经理编号',
  `ord_sertime` varchar(50) DEFAULT NULL COMMENT '服务时间',
  `ord_status` int(2) DEFAULT NULL COMMENT '支付状态：0=等待，1=成功，2=取消，3=已绑定，4=已绑定未使用',
  `ord_ordertype` int(2) DEFAULT '0' COMMENT '0代表第一次支付,非零代表续费',
  `ord_addtime` datetime DEFAULT NULL COMMENT '下订单时间',
  `ord_modtime` datetime DEFAULT NULL COMMENT '修改时间',
  `ord_color` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  `ord_imgurl` varchar(200) DEFAULT '',
  `ord_phone` varchar(20) DEFAULT NULL,
  `ord_receivename` varchar(100) DEFAULT NULL,
  `ord_proname` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`ord_id`),
  UNIQUE KEY `ord_no` (`ord_no`) USING BTREE,
  KEY `fk_refer1` (`u_id`) USING BTREE,
  KEY `IDX_ID` (`ord_id`),
  KEY `IDX_ORDNO` (`ord_no`),
  KEY `IDX_PRONO` (`pro_no`),
  KEY `IDX_MANAGERNO` (`ord_managerno`),
  CONSTRAINT `jx_order_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `jx_user` (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=414 DEFAULT CHARSET=utf8 COMMENT='支付订单表';

-- ----------------------------
-- Table structure for jx_partner
-- ----------------------------
DROP TABLE IF EXISTS `jx_partner`;
CREATE TABLE `jx_partner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '合伙人id',
  `par_name` varchar(50) DEFAULT NULL COMMENT '合伙人名字',
  `par_level` varchar(20) DEFAULT NULL COMMENT '合伙人级别',
  `par_parentid` bigint(20) DEFAULT NULL COMMENT '上级合伙人id',
  `par_parent` varchar(50) DEFAULT NULL COMMENT '上级合伙人',
  `par_area` varchar(100) DEFAULT NULL COMMENT '合伙人所在地区',
  `par_address` varchar(200) DEFAULT NULL COMMENT '联系地址',
  `par_phone` varchar(20) DEFAULT NULL COMMENT '联系人电话',
  `par_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  `par_sellernum` bigint(20) DEFAULT '0' COMMENT '合伙人销售设备的总台数',
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44030400000004 DEFAULT CHARSET=utf8 COMMENT='合伙人表';

-- ----------------------------
-- Table structure for jx_pay
-- ----------------------------
DROP TABLE IF EXISTS `jx_pay`;
CREATE TABLE `jx_pay` (
  `pay_id` bigint(100) NOT NULL AUTO_INCREMENT COMMENT '付费类型ID',
  `pay_typeid` bigint(20) DEFAULT NULL COMMENT '产品类型：1=壁挂式净水器，2=台式净水器，3=立式净水器',
  `pay_typename` bigint(50) DEFAULT NULL COMMENT '产品商品名称，0=包年包流量；1=按流量付费',
  `pay_totalmoney` float(20,2) DEFAULT NULL COMMENT '支付总金额',
  `pay_flow` float(20,2) DEFAULT NULL COMMENT '初始流量值',
  `pay_unitprice` float(20,2) DEFAULT NULL COMMENT '单位价格',
  PRIMARY KEY (`pay_id`),
  KEY `IDX_ID` (`pay_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='支付信息表';

-- ----------------------------
-- Table structure for jx_phcode
-- ----------------------------
DROP TABLE IF EXISTS `jx_phcode`;
CREATE TABLE `jx_phcode` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '验证码ID',
  `phone_no` varchar(50) DEFAULT NULL COMMENT '验证的手机号',
  `code_no` varchar(100) DEFAULT NULL COMMENT '验证码',
  `code_addtime` datetime DEFAULT NULL COMMENT '验证时间',
  `modtime` datetime DEFAULT NULL COMMENT '修改时间',
  `code_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `IDX_PHNO` (`phone_no`)
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8 COMMENT='手机验证码表';

-- ----------------------------
-- Table structure for jx_picture
-- ----------------------------
DROP TABLE IF EXISTS `jx_picture`;
CREATE TABLE `jx_picture` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '图片id',
  `protype_id` bigint(20) DEFAULT NULL COMMENT '产品类别图片id,关联jx_prototal表的PROT_ID，和jx_prodetail表的PROD_ID',
  `pic_color` varchar(200) DEFAULT NULL COMMENT '图片颜色',
  `pic_name` varchar(200) DEFAULT NULL COMMENT '图片名',
  `pic_url` varchar(300) DEFAULT NULL COMMENT '图片url',
  `pic_addtime` datetime DEFAULT NULL COMMENT '图片新增时间',
  `pic_modtime` datetime DEFAULT NULL COMMENT '图片修改时间',
  `pic_default` int(1) NOT NULL DEFAULT '0' COMMENT '默认字段1代表主页默认',
  `pic_tone` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`),
  KEY `IDX_PROTYPEID` (`protype_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='图片表';

-- ----------------------------
-- Table structure for jx_probri
-- ----------------------------
DROP TABLE IF EXISTS `jx_probri`;
CREATE TABLE `jx_probri` (
  `ID` bigint(20) NOT NULL COMMENT '简介ID	',
  `PROT_ID` bigint(20) DEFAULT NULL COMMENT '产品ID',
  `PROB_TITLE` varchar(200) DEFAULT NULL COMMENT '标题',
  `PROB_CLAUSE` varchar(1000) DEFAULT NULL COMMENT '介绍条目',
  `PROB_DETAIL` varchar(200) DEFAULT NULL COMMENT '其他介绍',
  PRIMARY KEY (`ID`),
  KEY `FK_Reference_13` (`PROT_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品简介表';

-- ----------------------------
-- Table structure for jx_prodetail
-- ----------------------------
DROP TABLE IF EXISTS `jx_prodetail`;
CREATE TABLE `jx_prodetail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '明细产品id',
  `prot_id` bigint(20) NOT NULL COMMENT '产品分类id，1=首页大图，2=明细的壁挂净水机，3=明细的台式净水机，4=明细的立式净水机',
  `prod_name` varchar(300) DEFAULT NULL COMMENT '明细产品名称',
  `prod_picid` bigint(20) DEFAULT NULL COMMENT '明细产品图片id',
  `prod_spec` varchar(1000) DEFAULT NULL COMMENT '明细产品说明',
  `prod_addtime` datetime DEFAULT NULL COMMENT '明细产品新增时间',
  `prod_modtime` datetime DEFAULT NULL COMMENT '明细产品修改时间',
  `prod_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `prot_id` (`prot_id`) USING BTREE,
  KEY `IDX_PICID` (`prod_picid`),
  KEY `IDX_PROTID` (`prot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='产品全明细表';

-- ----------------------------
-- Table structure for jx_product
-- ----------------------------
DROP TABLE IF EXISTS `jx_product`;
CREATE TABLE `jx_product` (
  `pro_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '产品id',
  `pro_code` varchar(100) DEFAULT NULL COMMENT '产品设备码',
  `pro_no` varchar(100) DEFAULT NULL COMMENT '产品编码',
  `u_id` bigint(20) DEFAULT NULL,
  `fam_id` bigint(20) DEFAULT NULL COMMENT '家庭id',
  `ph_no` varchar(20) DEFAULT NULL COMMENT '产品联系人电话',
  `pro_image` varchar(200) DEFAULT NULL COMMENT '图片id',
  `pro_name` varchar(100) DEFAULT NULL COMMENT '产品名称',
  `pro_category` bigint(20) DEFAULT NULL COMMENT '产品分类',
  `pro_color` varchar(10) DEFAULT NULL COMMENT '产品颜色',
  `pro_addtime` datetime DEFAULT NULL COMMENT '新增时间',
  `pro_modtime` datetime DEFAULT NULL COMMENT '修改时间',
  `pro_hasflow` float(20,4) DEFAULT NULL COMMENT '已使用流量',
  `pro_restflow` float(20,4) DEFAULT NULL COMMENT '剩余流量',
  `pro_invalidtime` datetime DEFAULT NULL COMMENT '产品到期失效时间',
  PRIMARY KEY (`pro_id`),
  KEY `IDX_PROID` (`pro_id`),
  KEY `IDX_PRONO` (`pro_no`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COMMENT='产品表';

-- ----------------------------
-- Table structure for jx_proflt
-- ----------------------------
DROP TABLE IF EXISTS `jx_proflt`;
CREATE TABLE `jx_proflt` (
  `prf_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '产品id',
  `prf_code` varchar(100) DEFAULT NULL COMMENT '产品设备码',
  `pro_no` varchar(200) NOT NULL COMMENT '产品编码',
  `prf_category` bigint(20) DEFAULT NULL COMMENT '产品分类',
  `prf_pp` decimal(8,2) DEFAULT NULL COMMENT 'pp滤芯',
  `prf_cto` decimal(8,2) DEFAULT NULL COMMENT 'cto活性炭滤芯',
  `prf_ro` decimal(8,2) DEFAULT NULL COMMENT 'ro膜滤芯',
  `prf_t33` decimal(8,2) DEFAULT NULL COMMENT 't33活性保鲜滤芯',
  `prf_wfr` decimal(8,2) DEFAULT NULL COMMENT '弱碱滤芯',
  `prf_addtime` datetime DEFAULT NULL COMMENT '新增时间',
  `prf_modtime` datetime DEFAULT NULL COMMENT '修改时间',
  `prf_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`prf_id`),
  KEY `fk_reference_4` (`pro_no`) USING BTREE,
  KEY `IDX_PRFID` (`prf_id`),
  KEY `IDX_PRONO` (`pro_no`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COMMENT='产品滤芯表'
/*!50100 PARTITION BY HASH (prf_id)
PARTITIONS 10 */;

-- ----------------------------
-- Table structure for jx_proflt_life
-- ----------------------------
DROP TABLE IF EXISTS `jx_proflt_life`;
CREATE TABLE `jx_proflt_life` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `pp` int(10) DEFAULT NULL,
  `cto` int(10) DEFAULT NULL,
  `ro` int(10) DEFAULT NULL,
  `t33` int(10) DEFAULT NULL,
  `wfr` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_prointro
-- ----------------------------
DROP TABLE IF EXISTS `jx_prointro`;
CREATE TABLE `jx_prointro` (
  `ID` bigint(20) NOT NULL COMMENT '说明ID',
  `PROT_ID` bigint(20) DEFAULT NULL COMMENT '产品ID',
  `PROI_TITLE` varchar(200) DEFAULT NULL COMMENT '说明标题',
  `PROI_DETAIL` varchar(1000) DEFAULT NULL COMMENT '说明条目',
  `PROI_OTHER` varchar(200) DEFAULT NULL COMMENT '其他说明',
  PRIMARY KEY (`ID`),
  KEY `FK_Referproin` (`PROT_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='包年费用说明表';

-- ----------------------------
-- Table structure for jx_propromise
-- ----------------------------
DROP TABLE IF EXISTS `jx_propromise`;
CREATE TABLE `jx_propromise` (
  `ID` bigint(20) NOT NULL COMMENT '服务承诺ID',
  `PROT_ID` bigint(20) DEFAULT NULL COMMENT '产品ID',
  `PROP_TITLE` varchar(200) DEFAULT NULL COMMENT '服务承诺标题',
  `PROP_ICOURL` varchar(200) DEFAULT NULL COMMENT '条目图标',
  `PROP_DETAIL` varchar(1000) DEFAULT NULL COMMENT '条目内容',
  `PROP_OTHER` varchar(200) DEFAULT NULL COMMENT '其他内容',
  PRIMARY KEY (`ID`),
  KEY `FK_Reference_16` (`PROT_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品服务承诺表';

-- ----------------------------
-- Table structure for jx_proserver
-- ----------------------------
DROP TABLE IF EXISTS `jx_proserver`;
CREATE TABLE `jx_proserver` (
  `ID` bigint(20) NOT NULL COMMENT '服务说明ID',
  `PROT_ID` bigint(20) DEFAULT NULL COMMENT '产品ID',
  `PROS_TITLE` varchar(200) DEFAULT NULL COMMENT '标题',
  `PROS_DETAIL` varchar(1000) DEFAULT NULL COMMENT '服务说明内容',
  `PROS_OTHER` varchar(200) DEFAULT NULL COMMENT '其他说明',
  PRIMARY KEY (`ID`),
  KEY `FK_Reference_15` (`PROT_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品服务说明表';

-- ----------------------------
-- Table structure for jx_prototal
-- ----------------------------
DROP TABLE IF EXISTS `jx_prototal`;
CREATE TABLE `jx_prototal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '产品总类id',
  `prot_type` int(11) NOT NULL COMMENT '产品分类 1=首页大图, 2=壁挂净水器，3=台式，4=立式',
  `prod_typename` varchar(255) DEFAULT NULL COMMENT '产品型号',
  `prot_name` varchar(50) DEFAULT NULL COMMENT '产品分类名称',
  `prot_picid` bigint(20) DEFAULT NULL COMMENT '产品类别图片id',
  `prod_fee` varchar(255) DEFAULT NULL COMMENT '包年费用',
  `prod_hz` varchar(255) DEFAULT NULL COMMENT '额定电压/频率',
  `prod_w` varchar(255) DEFAULT NULL COMMENT '加热功率',
  `prod_mpa` varchar(255) DEFAULT NULL COMMENT '进水压力',
  `prod_c` varchar(255) DEFAULT NULL COMMENT '环境温度',
  `prod_hl` varchar(255) DEFAULT NULL COMMENT '净水流量',
  `prod_fl` varchar(255) DEFAULT NULL COMMENT '过滤方式',
  `prod_wt` varchar(255) DEFAULT NULL COMMENT '适用水范围',
  `prod_iw` varchar(255) DEFAULT NULL COMMENT '出水水质',
  `prod_wx` varchar(255) DEFAULT NULL COMMENT '产品毛重',
  `prod_wd` varchar(255) DEFAULT NULL COMMENT '产品净重',
  `prod_sz` varchar(255) DEFAULT NULL COMMENT '产品尺寸',
  `prod_szi` varchar(255) DEFAULT NULL COMMENT '包装尺寸',
  `prot_addtime` datetime DEFAULT NULL COMMENT '分类产品新增时间',
  `prot_modtime` datetime DEFAULT NULL COMMENT '分类产品修改时间',
  `prot_status` bigint(20) DEFAULT NULL COMMENT '产品上架状态：0=线上，1=下架',
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`),
  KEY `IDX_PROTTYPE` (`prot_type`),
  KEY `IDX_PICID` (`prot_picid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_publish
-- ----------------------------
DROP TABLE IF EXISTS `jx_publish`;
CREATE TABLE `jx_publish` (
  `pub_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '发布id',
  `ph_no` varchar(20) DEFAULT NULL COMMENT '发布人关联手机号',
  `pub_name` varchar(100) DEFAULT NULL COMMENT '发布名',
  `pub_categoryid` bigint(20) DEFAULT NULL COMMENT '服务分类id',
  `pub_address` varchar(1000) DEFAULT NULL COMMENT '服务地址',
  `pub_sertime` datetime DEFAULT NULL COMMENT '服务时间',
  `pub_seller` varchar(200) DEFAULT NULL COMMENT '服务商家名称',
  `pub_url` varchar(200) DEFAULT NULL COMMENT '图片id',
  `pub_content` varchar(1000) DEFAULT NULL COMMENT '服务内容',
  `pub_vaildtime` varchar(100) DEFAULT NULL COMMENT '有效的发布开始时间',
  `pub_invildtime` varchar(100) DEFAULT NULL COMMENT '失效时间',
  `pub_addtime` datetime DEFAULT NULL COMMENT '发布时间',
  `pub_modtime` datetime DEFAULT NULL COMMENT '修改时间',
  `pub_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`pub_id`),
  KEY `IDX_ID` (`pub_id`),
  KEY `IDX_PHNO` (`ph_no`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8 COMMENT='社区发布表'
/*!50100 PARTITION BY HASH (pub_id)
PARTITIONS 10 */;

-- ----------------------------
-- Table structure for jx_pubpic
-- ----------------------------
DROP TABLE IF EXISTS `jx_pubpic`;
CREATE TABLE `jx_pubpic` (
  `pub_picid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '发布图片id',
  `pubtype_id` bigint(20) DEFAULT NULL COMMENT '产品类别图片id',
  `pic_url` varchar(300) DEFAULT NULL COMMENT '图片url',
  `pic_dir` varchar(200) DEFAULT NULL COMMENT '图片目录',
  `pic_name` varchar(200) DEFAULT NULL COMMENT '图片名',
  `pic_addtime` datetime DEFAULT NULL COMMENT '图片新增时间',
  `pic_modtime` datetime DEFAULT NULL COMMENT '图片修改时间',
  `pic_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`pub_picid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='发布图片表';

-- ----------------------------
-- Table structure for jx_share
-- ----------------------------
DROP TABLE IF EXISTS `jx_share`;
CREATE TABLE `jx_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `share_title` varchar(255) DEFAULT NULL,
  `share_content` varchar(255) DEFAULT NULL,
  `share_apkurl` varchar(255) DEFAULT NULL,
  `share_imgurl` varchar(255) DEFAULT NULL,
  `share_status` int(1) DEFAULT NULL,
  `share_addtime` datetime DEFAULT NULL,
  `share_modifytime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_tmpprodetail
-- ----------------------------
DROP TABLE IF EXISTS `jx_tmpprodetail`;
CREATE TABLE `jx_tmpprodetail` (
  `id` bigint(20) NOT NULL COMMENT '明细产品id',
  `prot_id` bigint(20) NOT NULL COMMENT '产品分类id，1=首页大图，2=明细的壁挂净水机，3=明细的台式净水机，4=明细的立式净水机',
  `prod_name` varchar(300) DEFAULT NULL COMMENT '明细产品名称',
  `pic_color` varchar(200) DEFAULT NULL COMMENT '图片颜色',
  `pic_tone` varchar(200) DEFAULT NULL COMMENT '图片色值',
  `prod_picid` bigint(20) DEFAULT NULL COMMENT '明细产品图片id',
  `prod_addtime` datetime DEFAULT NULL COMMENT '明细产品新增时间',
  `prod_modtime` datetime DEFAULT NULL COMMENT '明细产品修改时间',
  `pic_url` varchar(300) DEFAULT NULL COMMENT '图片url',
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`),
  KEY `IDX_PROTID` (`prot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_tmptable
-- ----------------------------
DROP TABLE IF EXISTS `jx_tmptable`;
CREATE TABLE `jx_tmptable` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT '临时表id',
  `tmp_value1` varchar(50) DEFAULT NULL COMMENT '临时值1',
  `tmp_value2` varchar(20) DEFAULT NULL COMMENT '临时值2',
  `tmp_num1` bigint(20) DEFAULT NULL COMMENT '临时数值1',
  `tmp_value3` varchar(50) DEFAULT NULL COMMENT '临时值3',
  `tmp_value4` varchar(100) DEFAULT NULL COMMENT '临时值4',
  `tmp_value5` varchar(200) DEFAULT NULL COMMENT '临时值5',
  `tmp_value6` varchar(20) DEFAULT NULL COMMENT '临时值6',
  `tmp_value7` varchar(200) DEFAULT NULL COMMENT '临时值7',
  `tmp_num2` bigint(21) DEFAULT '0' COMMENT '临时数值2',
  KEY `IDX_ID` (`tmp_value1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='临时表';

-- ----------------------------
-- Table structure for jx_upflt
-- ----------------------------
DROP TABLE IF EXISTS `jx_upflt`;
CREATE TABLE `jx_upflt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '滤芯ID',
  `JX__U_ID` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `flt_no` varchar(50) DEFAULT NULL COMMENT '滤芯编号',
  `pro_id` varchar(50) DEFAULT NULL COMMENT '设备编号',
  `manager_no` varchar(50) DEFAULT NULL COMMENT '业务经理编号',
  `flt_addtime` datetime DEFAULT NULL COMMENT '更新时间',
  `flt_othertime` datetime DEFAULT NULL COMMENT '修改时间',
  `flt_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_12` (`JX__U_ID`) USING BTREE,
  KEY `IDX_ID` (`id`),
  KEY `IDX_UID` (`JX__U_ID`),
  CONSTRAINT `jx_upflt_ibfk_1` FOREIGN KEY (`JX__U_ID`) REFERENCES `jx_user` (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='滤芯更换表';

-- ----------------------------
-- Table structure for jx_user
-- ----------------------------
DROP TABLE IF EXISTS `jx_user`;
CREATE TABLE `jx_user` (
  `u_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `u_phone` varchar(20) NOT NULL COMMENT '注册手机号码',
  `u_name` varchar(50) DEFAULT NULL COMMENT '用户名称',
  `u_pwd` varchar(100) DEFAULT NULL COMMENT '用户密码',
  `u_status` int(1) DEFAULT NULL COMMENT '用户状态',
  `u_sex` int(1) DEFAULT NULL COMMENT '用户性别',
  `u_snname` varchar(100) DEFAULT NULL COMMENT '用户昵称',
  `u_txttail` varchar(300) DEFAULT NULL COMMENT '个人签名',
  `u_picurl` varchar(300) DEFAULT NULL COMMENT '用户头像url',
  `u_addtime` datetime DEFAULT NULL COMMENT '用户注册时间',
  `u_modtime` datetime DEFAULT NULL COMMENT '修改时间',
  `u_pwdmodtime` datetime DEFAULT NULL COMMENT '密码重置时间',
  `u_other` varchar(200) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`u_id`),
  KEY `IDX_UID` (`u_id`),
  KEY `IDX_UPHONE` (`u_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Table structure for jx_version
-- ----------------------------
DROP TABLE IF EXISTS `jx_version`;
CREATE TABLE `jx_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apk_digest` varchar(255) DEFAULT NULL,
  `apk_icon` varchar(255) DEFAULT NULL,
  `apk_md5` varchar(255) DEFAULT NULL,
  `apk_name` varchar(255) DEFAULT NULL,
  `apk_path` varchar(255) DEFAULT NULL,
  `apk_size` varchar(255) DEFAULT NULL,
  `apk_url` varchar(255) DEFAULT NULL,
  `apk_version` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `icon_md5` varchar(255) DEFAULT NULL,
  `system_version` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `mustupgrade` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for jx_webversion
-- ----------------------------
DROP TABLE IF EXISTS `jx_webversion`;
CREATE TABLE `jx_webversion` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '版本id',
  `ver_type` varchar(100) DEFAULT NULL COMMENT '版本类型',
  `ver_newnum` varchar(100) DEFAULT NULL COMMENT '新版本号',
  `ver_newurl` varchar(300) DEFAULT NULL COMMENT '新版本更新url',
  `ver_dir` varchar(300) DEFAULT NULL COMMENT '新版本软件目录',
  `ver_status` int(2) DEFAULT NULL COMMENT '状态：0=有效，1=无效',
  `ver_other` varchar(200) DEFAULT NULL COMMENT '扩展字段 ',
  PRIMARY KEY (`id`),
  KEY `IDX_ID` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='版本更新表';

-- ----------------------------
-- Table structure for qrtz_calendars
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars` (
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for qrtz_fired_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers` (
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `IS_VOLATILE` varchar(1) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_STATEFUL` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ENTRY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for qrtz_job_details
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details` (
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_VOLATILE` varchar(1) NOT NULL,
  `IS_STATEFUL` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for qrtz_job_listeners
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_listeners`;
CREATE TABLE `qrtz_job_listeners` (
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `JOB_LISTENER` varchar(200) NOT NULL,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`,`JOB_LISTENER`),
  KEY `JOB_NAME` (`JOB_NAME`,`JOB_GROUP`) USING BTREE,
  CONSTRAINT `qrtz_job_listeners_ibfk_1` FOREIGN KEY (`JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='InnoDB free: 15360 kB; (`JOB_NAME` `JOB_GROUP`) REFER `qc_pu';

-- ----------------------------
-- Table structure for qrtz_locks
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks` (
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for qrtz_paused_trigger_grps
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for qrtz_scheduler_state
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state` (
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  PRIMARY KEY (`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for qrtz_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers` (
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `IS_VOLATILE` varchar(1) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `JOB_NAME` (`JOB_NAME`,`JOB_GROUP`) USING BTREE,
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='InnoDB free: 15360 kB; (`JOB_NAME` `JOB_GROUP`) REFER `qc_pu';

-- ----------------------------
-- Table structure for qrtz_trigger_listeners
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_trigger_listeners`;
CREATE TABLE `qrtz_trigger_listeners` (
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `TRIGGER_LISTENER` varchar(200) NOT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_LISTENER`),
  KEY `TRIGGER_NAME` (`TRIGGER_NAME`,`TRIGGER_GROUP`) USING BTREE,
  CONSTRAINT `qrtz_trigger_listeners_ibfk_1` FOREIGN KEY (`TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='InnoDB free: 15360 kB; (`TRIGGER_NAME` `TRIGGER_GROUP`) REFE';

-- ----------------------------
-- Table structure for sys_announcement
-- ----------------------------
DROP TABLE IF EXISTS `sys_announcement`;
CREATE TABLE `sys_announcement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `content` varchar(2000) DEFAULT NULL,
  `t_end` datetime DEFAULT NULL,
  `t_start` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_dic
-- ----------------------------
DROP TABLE IF EXISTS `sys_dic`;
CREATE TABLE `sys_dic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `val1` varchar(255) DEFAULT NULL,
  `val2` varchar(255) DEFAULT NULL,
  `val3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_dicitem
-- ----------------------------
DROP TABLE IF EXISTS `sys_dicitem`;
CREATE TABLE `sys_dicitem` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `val1` varchar(255) DEFAULT NULL,
  `val2` varchar(255) DEFAULT NULL,
  `val3` varchar(255) DEFAULT NULL,
  `val4` varchar(255) DEFAULT NULL,
  `d_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE380D91FA311F05D` (`d_code`) USING BTREE,
  KEY `FKE380D91FACE41163` (`d_code`) USING BTREE,
  CONSTRAINT `sys_dicitem_ibfk_1` FOREIGN KEY (`d_code`) REFERENCES `sys_dic` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='InnoDB free: 15360 kB; (`d_code`) REFER `qc_push/sys_dic`(`c';

-- ----------------------------
-- Table structure for sys_email
-- ----------------------------
DROP TABLE IF EXISTS `sys_email`;
CREATE TABLE `sys_email` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `defaultfrom` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_history
-- ----------------------------
DROP TABLE IF EXISTS `sys_history`;
CREATE TABLE `sys_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `entity` varchar(255) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  `operation_code` varchar(255) DEFAULT NULL,
  `operation_type` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `session_code` bigint(20) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_history_item
-- ----------------------------
DROP TABLE IF EXISTS `sys_history_item`;
CREATE TABLE `sys_history_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `new_value` varchar(2000) DEFAULT NULL,
  `previous_value` varchar(2000) DEFAULT NULL,
  `property` varchar(255) DEFAULT NULL,
  `history_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5184EC10F8824CB1` (`history_id`) USING BTREE,
  KEY `FK5184EC109AB07AB7` (`history_id`) USING BTREE,
  CONSTRAINT `sys_history_item_ibfk_1` FOREIGN KEY (`history_id`) REFERENCES `sys_history` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='InnoDB free: 15360 kB; (`history_id`) REFER `qc_push/sys_his';

-- ----------------------------
-- Table structure for sys_journal
-- ----------------------------
DROP TABLE IF EXISTS `sys_journal`;
CREATE TABLE `sys_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `creat_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `domain_id` bigint(20) DEFAULT NULL,
  `domain_label` varchar(255) DEFAULT NULL,
  `operation_code` int(11) DEFAULT NULL,
  `operator_ip_addr` varchar(255) DEFAULT NULL,
  `operator_name` varchar(255) DEFAULT NULL,
  `session_code` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1413 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_log_integr
-- ----------------------------
DROP TABLE IF EXISTS `sys_log_integr`;
CREATE TABLE `sys_log_integr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_code` varchar(255) DEFAULT NULL,
  `creat_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `operation_code` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `session_code` bigint(20) DEFAULT NULL,
  `trade_seq` varchar(255) DEFAULT NULL,
  `trade_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_log_integr_soap
-- ----------------------------
DROP TABLE IF EXISTS `sys_log_integr_soap`;
CREATE TABLE `sys_log_integr_soap` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `business_code` varchar(255) DEFAULT NULL,
  `cxfid` varchar(255) DEFAULT NULL,
  `in_time` datetime DEFAULT NULL,
  `log_in` varchar(255) DEFAULT NULL,
  `log_out` varchar(255) DEFAULT NULL,
  `out_time` datetime DEFAULT NULL,
  `trade_seq` varchar(255) DEFAULT NULL,
  `trade_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_quartz
-- ----------------------------
DROP TABLE IF EXISTS `sys_quartz`;
CREATE TABLE `sys_quartz` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_by` varchar(255) DEFAULT NULL,
  `last_modify_time` datetime DEFAULT NULL,
  `classname` varchar(255) DEFAULT NULL,
  `cron` bit(1) NOT NULL,
  `q_cron` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `jobdata` varchar(255) DEFAULT NULL,
  `millis` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `pause` bit(1) NOT NULL,
  `q_repeat` int(11) DEFAULT NULL,
  `q_qrepeat_int` int(11) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `system` bit(1) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- View structure for view_30days
-- ----------------------------
DROP VIEW IF EXISTS `view_30days`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `view_30days` AS select curdate() AS `dd` union all select (curdate() - interval 1 day) AS `dd` union all select (curdate() - interval 2 day) AS `dd` union all select (curdate() - interval 3 day) AS `dd` union all select (curdate() - interval 4 day) AS `dd` union all select (curdate() - interval 5 day) AS `dd` union all select (curdate() - interval 6 day) AS `dd` union all select (curdate() - interval 7 day) AS `dd` union all select (curdate() - interval 8 day) AS `dd` union all select (curdate() - interval 9 day) AS `dd` union all select (curdate() - interval 10 day) AS `dd` union all select (curdate() - interval 11 day) AS `dd` union all select (curdate() - interval 12 day) AS `dd` union all select (curdate() - interval 13 day) AS `dd` union all select (curdate() - interval 14 day) AS `dd` union all select (curdate() - interval 15 day) AS `dd` union all select (curdate() - interval 16 day) AS `dd` union all select (curdate() - interval 17 day) AS `dd` union all select (curdate() - interval 18 day) AS `dd` union all select (curdate() - interval 19 day) AS `dd` union all select (curdate() - interval 20 day) AS `dd` union all select (curdate() - interval 21 day) AS `dd` union all select (curdate() - interval 22 day) AS `dd` union all select (curdate() - interval 23 day) AS `dd` union all select (curdate() - interval 24 day) AS `dd` union all select (curdate() - interval 25 day) AS `dd` union all select (curdate() - interval 26 day) AS `dd` union all select (curdate() - interval 27 day) AS `dd` union all select (curdate() - interval 28 day) AS `dd` union all select (curdate() - interval 29 day) AS `dd` ;

-- ----------------------------
-- Procedure structure for PRO_ADDSELLNUM
-- ----------------------------
DROP PROCEDURE IF EXISTS `PRO_ADDSELLNUM`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `PRO_ADDSELLNUM`()
BEGIN  
 DECLARE err_status VARCHAR( 100)  ;
 DECLARE CONTINUE HANDLER 
    FOR 1062
    SET err_status = 'err_status '
 ;
/* 4级代理销售数量统计  */
-- TRUNCATE TABLE JXDB.JX_ADDSELLNUM;
DELETE FROM  JXDB.JX_ADDSELLNUM;
DELETE FROM  JX_TMPTABLE;
-- DROP TABLE IF EXISTS JX_TMPTABLE;  
-- CREATE TEMPORARY TABLE JX_TMPTABLE 
INSERT INTO JX_TMPTABLE
SELECT * FROM ( SELECT B.ID,B.PAR_NAME,B.PAR_LEVEL,PAR_PARENTID,B.PAR_PARENT,B.PAR_AREA,B.PAR_ADDRESS,B.PAR_PHONE,B.PAR_OTHER,A.PAR_SELLERNUM 
FROM JXDB.JX_PARTNER B 
INNER JOIN (
SELECT DISTINCT B.ID AS ID,COUNT(1) AS PAR_SELLERNUM FROM JXDB.JX_ORDER A
INNER JOIN JXDB.JX_PARTNER B
ON A.ORD_MANAGERNO=B.ID
WHERE ORD_STATUS in ('3','4')  -- 0=等待，1=成功，2=取消
GROUP BY B.ID ) A  
ON B.ID=A.ID ) AS TOTA;

DELETE FROM JXDB.JX_ADDSELLNUM  
 WHERE PAR_LEVEL='4' ;

INSERT INTO JXDB.JX_ADDSELLNUM (PAR_NO,PAR_NAME,PAR_LEVEL,PAR_PARENTID,PAR_PARENT,PAR_AREA,PAR_ADDRESS,PAR_PHONE,PAR_OTHER,PAR_SELLERNUM)
SELECT * FROM JX_TMPTABLE AS TOTA;

/* 3级代理销售数量统计  */
-- DROP TABLE IF EXISTS JX_TMPTABLE1;  
DELETE FROM  JX_TMPTABLE;
-- DROP TABLE IF EXISTS JX_TMPTABLE;  
-- CREATE TEMPORARY TABLE JX_TMPTABLE 
INSERT INTO JX_TMPTABLE
SELECT * FROM ( SELECT B.ID,B.PAR_NAME,B.PAR_LEVEL,PAR_PARENTID,B.PAR_PARENT,B.PAR_AREA,B.PAR_ADDRESS,B.PAR_PHONE,B.PAR_OTHER,A.PAR_SELLERNUM 
FROM JXDB.JX_PARTNER B 
INNER JOIN (SELECT ID,SUM(PAR_SELLERNUM)AS PAR_SELLERNUM FROM (
SELECT DISTINCT A.ID AS ID,B.PAR_SELLERNUM AS PAR_SELLERNUM
 FROM JX_PARTNER A 
INNER JOIN JX_ADDSELLNUM B
ON A.ID=B.PAR_NO
WHERE B.PAR_LEVEL='3'
GROUP BY A.PAR_SELLERNUM
UNION ALL
SELECT DISTINCT A.ID AS ID,SUM(B.PAR_SELLERNUM) AS PAR_SELLERNUM
 FROM JX_PARTNER A 
INNER JOIN JX_ADDSELLNUM B
ON A.ID=B.PAR_PARENTID
WHERE B.PAR_LEVEL='4'
GROUP BY A.ID ) AS TOT
GROUP BY ID ) A  
ON B.ID=A.ID ) AS TOTA;


 

DELETE FROM JXDB.JX_ADDSELLNUM  
 WHERE PAR_LEVEL='3' ;

INSERT INTO JXDB.JX_ADDSELLNUM (PAR_NO,PAR_NAME,PAR_LEVEL,PAR_PARENTID,PAR_PARENT,PAR_AREA,PAR_ADDRESS,PAR_PHONE,PAR_OTHER,PAR_SELLERNUM)
SELECT * FROM JX_TMPTABLE AS TOTA;


/* 2级代理销售数量统计  */
-- DROP TABLE IF EXISTS JX_TMPTABLE2;  
DELETE FROM  JX_TMPTABLE;
-- DROP TABLE IF EXISTS JX_TMPTABLE;  
-- CREATE TEMPORARY TABLE JX_TMPTABLE 
INSERT INTO JX_TMPTABLE
SELECT * FROM ( SELECT B.ID,B.PAR_NAME,B.PAR_LEVEL,PAR_PARENTID,B.PAR_PARENT,B.PAR_AREA,B.PAR_ADDRESS,B.PAR_PHONE,B.PAR_OTHER,A.PAR_SELLERNUM 
FROM JXDB.JX_PARTNER B 
INNER JOIN (SELECT ID,SUM(PAR_SELLERNUM)AS PAR_SELLERNUM FROM (
SELECT DISTINCT A.ID AS ID,B.PAR_SELLERNUM AS PAR_SELLERNUM
 FROM JX_PARTNER A 
INNER JOIN JX_ADDSELLNUM B
ON A.ID=B.PAR_NO
WHERE B.PAR_LEVEL='2'
GROUP BY A.PAR_SELLERNUM
UNION ALL
SELECT DISTINCT A.ID AS ID,SUM(B.PAR_SELLERNUM) AS PAR_SELLERNUM
 FROM JX_PARTNER A 
INNER JOIN JX_ADDSELLNUM B
ON A.ID=B.PAR_PARENTID
WHERE B.PAR_LEVEL='3'
GROUP BY A.ID ) AS TOT
GROUP BY ID ) A  
ON B.ID=A.ID ) AS TOTA;

DELETE FROM JXDB.JX_ADDSELLNUM  
 WHERE PAR_LEVEL='2' ;

INSERT INTO JXDB.JX_ADDSELLNUM (PAR_NO,PAR_NAME,PAR_LEVEL,PAR_PARENTID,PAR_PARENT,PAR_AREA,PAR_ADDRESS,PAR_PHONE,PAR_OTHER,PAR_SELLERNUM)
SELECT * FROM JX_TMPTABLE AS TOTA;


/* 1级代理销售数量统计  */
-- DROP TABLE IF EXISTS JX_TMPTABLE3;  
DELETE FROM  JX_TMPTABLE;
-- DROP TABLE IF EXISTS JX_TMPTABLE;  
-- CREATE TEMPORARY TABLE JX_TMPTABLE 
INSERT INTO JX_TMPTABLE
SELECT * FROM ( SELECT B.ID,B.PAR_NAME,B.PAR_LEVEL,PAR_PARENTID,B.PAR_PARENT,B.PAR_AREA,B.PAR_ADDRESS,B.PAR_PHONE,B.PAR_OTHER,A.PAR_SELLERNUM 
FROM JXDB.JX_PARTNER B 
INNER JOIN (SELECT ID,SUM(PAR_SELLERNUM)AS PAR_SELLERNUM FROM (
SELECT DISTINCT A.ID AS ID,B.PAR_SELLERNUM AS PAR_SELLERNUM
 FROM JX_PARTNER A 
INNER JOIN JX_ADDSELLNUM B
ON A.ID=B.PAR_NO
WHERE B.PAR_LEVEL='1'
GROUP BY A.PAR_SELLERNUM
UNION ALL
SELECT DISTINCT A.ID AS ID,SUM(B.PAR_SELLERNUM) AS PAR_SELLERNUM
 FROM JX_PARTNER A 
INNER JOIN JX_ADDSELLNUM B
ON A.ID=B.PAR_PARENTID
WHERE B.PAR_LEVEL='2'
GROUP BY A.ID ) AS TOT
GROUP BY ID ) A  
ON B.ID=A.ID ) AS TOTA;

DELETE FROM JXDB.JX_ADDSELLNUM  
 WHERE PAR_LEVEL='1' ;

INSERT INTO JXDB.JX_ADDSELLNUM (PAR_NO,PAR_NAME,PAR_LEVEL,PAR_PARENTID,PAR_PARENT,PAR_AREA,PAR_ADDRESS,PAR_PHONE,PAR_OTHER,PAR_SELLERNUM)
SELECT * FROM JX_TMPTABLE AS TOTA;

/* 更新PARTNER 表 */

UPDATE JXDB.JX_PARTNER SET PAR_SELLERNUM= 0;

UPDATE JXDB.JX_PARTNER A
INNER JOIN JXDB.JX_ADDSELLNUM B  

SET A.PAR_SELLERNUM=B.PAR_SELLERNUM
WHERE A.ID = B.PAR_NO

;
--  DELETE FROM  JX_TMPTABLE;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for PRO_AUTOADDNUM
-- ----------------------------
DROP PROCEDURE IF EXISTS `PRO_AUTOADDNUM`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `PRO_AUTOADDNUM`()
BEGIN  

DECLARE no_more_record INT DEFAULT 0;
DECLARE pID BIGINT (20);
DECLARE err_status VARCHAR( 100)  ;

DECLARE cur_record CURSOR FOR   --  ID ,PAR_SELLERNUM
SELECT
	ID
FROM
	JXDB.jx_partner GROUP BY ID; 

 DECLARE CONTINUE HANDLER 
    FOR 1062
    SET err_status = 'err_status '
 ;




DECLARE CONTINUE HANDLER FOR NOT FOUND

SET no_more_record = 1;
/*这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1*/
DELETE FROM  JXDB.jx_tmptable;
DELETE FROM  JXDB.JX_ADDSELLNUM;

INSERT INTO JX_ADDSELLNUM (par_no,par_name,par_level,par_parentid,par_parent,par_area,par_phone,par_sellernum)
 SELECT par_no,par_name,par_level,par_parentid,par_parent,par_area,par_phone,par_sellernum FROM 
(SELECT B.ID AS par_no,B.PAR_NAME,B.PAR_LEVEL,PAR_PARENTID,B.PAR_PARENT,B.PAR_AREA,B.PAR_PHONE,B.PAR_OTHER,A.PAR_SELLERNUM 
FROM JXDB.JX_PARTNER B 
INNER JOIN (
SELECT DISTINCT B.ID AS ID,COUNT(1) AS PAR_SELLERNUM FROM JXDB.JX_ORDER A
INNER JOIN JXDB.JX_PARTNER B
ON A.ORD_MANAGERNO=B.ID
WHERE ORD_STATUS in ('3','4')
GROUP BY B.ID ) A  
ON B.ID=A.ID ) AS TB;


OPEN cur_record;
/*接着使用OPEN打开游标*/
FETCH cur_record INTO pID;
/*把第一行数据写入变量中,游标也随之指向了记录的第一行*/


WHILE no_more_record !=1 DO
    -- UPDATE JXDB.JX_ADDSELLNUM SET 
   INSERT into jx_tmptable (tmp_value1,tmp_num2)
	 select pID ,sum(par_sellernum) AS tmp_num2 from JX_ADDSELLNUM 
where FIND_IN_SET(par_no, findsellTOtalnum(pID))
-- UPDATE jx_addsellnum a INNER JOIN 
-- set a.par_sellernum=b.tmp_num1
-- WHERE a.id=b.id


;
FETCH cur_record INTO pID;
END
WHILE;
CLOSE cur_record;

UPDATE jx_partner a INNER JOIN  jx_tmptable b 
set a.par_sellernum=b.tmp_num2
where a.id=b.tmp_value1;



END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for PRO_AUTOMESS
-- ----------------------------
DROP PROCEDURE IF EXISTS `PRO_AUTOMESS`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `PRO_AUTOMESS`()
BEGIN
UPDATE jx_message SET mess_lastdate=DATEDIFF(mess_invalidtime,NOW())
where mess_typename=1
;  -- 每天同一时间更新每个包年收费的客户的到期天数


END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for findsellTOtalnum
-- ----------------------------
DROP FUNCTION IF EXISTS `findsellTOtalnum`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `findsellTOtalnum`(sellId VARCHAR(400)) RETURNS varchar(4000) CHARSET utf8
BEGIN
DECLARE sTemp VARCHAR(4000);
DECLARE sTempChd VARCHAR(4000);

SET sTemp='$';
-- SET sTempChd = CAST(sellId AS CHAR);
SET sTempChd = sellId;
WHILE sTempChd IS NOT NULL DO
SET sTemp= CONCAT(sTemp,',',sTempChd);
SELECT GROUP_CONCAT(id) INTO sTempChd FROM jxdb.jx_partner WHERE FIND_IN_SET(PAR_PARENTID,sTempChd)>0;
END WHILE;
RETURN sTemp;
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for rand_decimal
-- ----------------------------
DROP FUNCTION IF EXISTS `rand_decimal`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `rand_decimal`(n INT) RETURNS decimal(20,4)
BEGIN
	DECLARE inta_num DECIMAL (20, 2);
	DECLARE i INT DEFAULT 0;
	WHILE i < n DO
		SET inta_num = rand() * 10;
		SET i = i + 1;
	END WHILE;
RETURN inta_num;
END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for rand_varchar
-- ----------------------------
DROP FUNCTION IF EXISTS `rand_varchar`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `rand_varchar`(n INT) RETURNS varchar(255) CHARSET utf8
BEGIN
    DECLARE chars_str varchar(100) DEFAULT 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    DECLARE return_str varchar(255) DEFAULT '';
    DECLARE i INT DEFAULT 0;
    WHILE i < n DO
        SET return_str = concat(return_str,substring(chars_str , FLOOR(1 + RAND()*62 ),1));
        SET i = i +1;
    END WHILE;
    RETURN return_str;
END
;;
DELIMITER ;

-- ----------------------------
-- Event structure for event_addsellnum
-- ----------------------------
DROP EVENT IF EXISTS `event_addsellnum`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` EVENT `event_addsellnum` ON SCHEDULE AT '2016-12-23 10:31:45' ON COMPLETION NOT PRESERVE DISABLE COMMENT '统计各级合伙人、业务经理业务量。' DO CALL PRO_AUTOADDNUM()
;;
DELIMITER ;

-- ----------------------------
-- Event structure for event_automess
-- ----------------------------
DROP EVENT IF EXISTS `event_automess`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` EVENT `event_automess` ON SCHEDULE EVERY 1 DAY STARTS '2016-12-25 00:31:00' ON COMPLETION NOT PRESERVE ENABLE DO call PRO_AUTOMESS()
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `tri_addsellnum`;
DELIMITER ;;
CREATE TRIGGER `tri_addsellnum` AFTER INSERT ON `jx_order` FOR EACH ROW begin
call pro_autoaddnum();
end
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `tri_addsellnum_update`;
DELIMITER ;;
CREATE TRIGGER `tri_addsellnum_update` AFTER UPDATE ON `jx_order` FOR EACH ROW begin
call pro_autoaddnum();
end
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `tri_addsellnum_delete`;
DELIMITER ;;
CREATE TRIGGER `tri_addsellnum_delete` AFTER DELETE ON `jx_order` FOR EACH ROW begin
call pro_autoaddnum();
end
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `tri_insertnews`;
DELIMITER ;;
CREATE TRIGGER `tri_insertnews` AFTER INSERT ON `jx_product` FOR EACH ROW begin
DECLARE COUNTrow  INT;
SET @NUM=DATEDIFF(new.pro_invalidtime,NOW());
SET @FLOWNUM=new.pro_restflow ;
SET COUNTrow = (select COUNT(PRO_NO)  from jx_order b
where  B.ord_STATUS=4  
AND  B.PRO_NO=NEW.PRO_NO 
);
IF COUNTrow  < 1  THEN
IF @NUM < 30 or @FLOWNUM < 100 then 
INSERT INTO JX_MESSAGES(
u_id,
title,
content,
nextparams,
isread,
type
) 
  SELECT A.U_ID,(CASE WHEN C.pay_typename='0' THEN "包年服务费用"
           WHEN C.pay_typename='1' THEN "流量服务费用"
  END)  AS TITLE,
(CASE WHEN C.pay_typename='0' THEN CONCAT(new.PRO_NAME,"(",new.PRO_COLOR,")","包年服务费剩余",CAST(DATEDIFF(new.pro_invalidtime,NOW()) AS CHAR),"天,",new.pro_invalidtime,"到期"  ) 
           WHEN C.pay_typename='1' THEN CONCAT(new.PRO_NAME,"(",new.PRO_COLOR,")","流量付费,目前已使用",new.pro_hasflow,"剩余",new.pro_restflow )
  END) AS CONTENT, 
  A.PRO_NO,
  0,
  0
from jx_product A
INNER JOIN jx_order B
ON A.PRO_NO=B.PRO_NO
INNER JOIN jx_pay C
ON A.pro_category=C.PAY_TYPEID
AND B.ord_protypeid=C.pay_typename
 where a.pro_id=new.pro_id
 AND B.ord_STATUS=3
 ;
end if ;
END IF ;
end
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `tri_updatenews`;
DELIMITER ;;
CREATE TRIGGER `tri_updatenews` AFTER UPDATE ON `jx_product` FOR EACH ROW begin
DECLARE COUNTrow  INT;
SET @NUM=DATEDIFF(new.pro_invalidtime,NOW());
SET @FLOWNUM=new.pro_restflow ;
SET COUNTrow = (select COUNT(PRO_NO)  from jx_order b
where  B.ord_STATUS=4  
AND  B.PRO_NO=NEW.PRO_NO 
);
DELETE FROM JX_MESSAGES WHERE nextparams=new.PRO_NO;
IF COUNTrow  < 1  THEN
IF @NUM < 30 or @FLOWNUM < 100 then 
INSERT INTO JX_MESSAGES(
u_id,
title,
content,
nextparams,
isread,
type
) 
  SELECT A.U_ID,(CASE WHEN C.pay_typename='0' THEN "包年服务费用"
           WHEN C.pay_typename='1' THEN "流量服务费用"
  END)  AS TITLE,
(CASE WHEN C.pay_typename='0' THEN CONCAT(new.PRO_NAME,"(",new.PRO_COLOR,")","包年服务费剩余",CAST(DATEDIFF(new.pro_invalidtime,NOW()) AS CHAR),"天,",new.pro_invalidtime,"到期"  ) 
           WHEN C.pay_typename='1' THEN CONCAT(new.PRO_NAME,"(",new.PRO_COLOR,")","流量付费,目前已使用",new.pro_hasflow ,"。剩余流量",new.pro_restflow )
  END) AS CONTENT, 
  A.PRO_NO,
  0,
  0
from jx_product A
INNER JOIN jx_order B
ON A.PRO_NO=B.PRO_NO
INNER JOIN jx_pay C
ON A.pro_category=C.PAY_TYPEID
AND B.ord_protypeid=C.pay_typename
 where a.pro_id=new.pro_id
 AND B.ord_STATUS=3
 ;

end if; 
END IF ;
--  call pro_automess();
end
;;
DELIMITER ;
