一、账号 
192.168.1.37:3306
zhangxin
123456

113.106.93.195:3366
root
uhjg!$2Ale0j#*R9

jxuser
wAd#3j*lR^s02y!8    --这个账户可用于连接客户端

二、产品经理或者合伙人净水器合同交易量的更新：主要通过触发器（tri_addsellnum、tri_addsellnum_update、tri_addsellnum_delete）调用PRO_AUTOADDNUM存储过程，目前195服务器上是启用事件event_addsellnum，完成自动更新。
如果重启服务器或者数据库，请启用事件 SET GLOBAL EVENT_SCHEDULER=ON;





其他MYSQL常用语法：


查数据库 ：SHOW DATABSES;
查表：show tables;	select * from information_schema.tables;
查外键关系:select constraint_name from information_schema.key_column_usage where table_schema='jxdb';或者 select * from information_schema.key_column_usage where table_schema='jxdb' and CONSTRAINT_NAME LIKE 'fk_re%'
查存储过程:show procedure status; select * from mysql.proc where db='jxdb';
查触发器:select * from information_schema.triggers;
查键关系和约束： select * from  information_schema.key_column_usage where table_schema'jxdb'；
查表中索引  ：use jxdb;
SELECT * from information_schema.STATISTICS
where TABLE_NAME='jx_order' and INDEX_SCHEMA='jxdb'
2016-12-05 10:46:18
查锁表情况   show status  like '%lock%';
查锁表       show open tables  where in_use > 0;
show processlist ;
查询正锁表 select * from information_schema.innodb_locks;
查询表结构 DESCRIBE TABLENAME 或者 desc tablename

新增表数据时可以筛选重复数据， on duplicate key update id=values(id) 

查询数据库大小

select TABLE_SCHEMA, concat(truncate(sum(data_length)/1024/1024,2),' MB') as data_size,
concat(truncate(sum(index_length)/1024/1024,2),'MB') as index_size
from information_schema.tables
group by TABLE_SCHEMA
order by data_length desc

查询表大小的
select TABLE_NAME,table_rows, concat(truncate(data_length/1024/1024,2),' MB') as data_size,
concat(truncate(index_length/1024/1024,2),' MB') as index_size
from information_schema.tables where TABLE_SCHEMA = 'jxdb'
AND TABLE_NAME LIKE 'jx_%'
group by TABLE_NAME
order by data_length desc;

SHOW VARIABLES LIKE '%query_cache%';
-- SET GLOBAL query_cache_type= on ;
show variables like "%innodb%";
show status like  'Innodb_buffer_pool_%';


清空数据加 SET foreign_key_checks=0;
清空reload表 flush tables 
flush tables tablename 


比较两个数据库的差异
SELECT
	a.TABLE_SCHEMA AS 线上服务器,
	a.TABLE_NAME AS 线上服务器已有表,
  c.table_comment AS 线上服务器已有表中文注释,
	a.COLUMN_NAME AS 线上服务器已有表字段,
  a.COLUMN_COMMENT  AS 线上已有表字段中文注释,
	a.DATA_TYPE AS 线上服务器已有表类型,
	a.COLUMN_DEFAULT
FROM
	diffonlinedb.`COLUMNS` a
INNER JOIN 	diff37db.`TABLES` c
on a.TABLE_NAME=c.TABLE_NAME
WHERE
	a.TABLE_SCHEMA = 'jxdb'
AND a.COLUMN_NAME NOT IN (
	SELECT
		b.COLUMN_NAME
	FROM
		diff37db.`COLUMNS` b
	WHERE
		b.TABLE_SCHEMA = 'jxdb'
	AND a.TABLE_SCHEMA = 'jxdb'
	AND a.TABLE_NAME = b.TABLE_NAME
) ORDER BY a.TABLE_NAME desc

查询数据库总行数
select table_name,table_rows from tables
where TABLE_SCHEMA = '数据库名'
order by table_rows desc


MYSQL数据表出现问题，提示：
Error: Table './db_name/table_name' is marked as crashed and last (automatic?) repair failed
修复数据表操作：
1、service mysqld stop;
2、cd /var/lib/mysql/db_name/
3、myisamchk -r tablename.MYI (修复单张数据表)
myisamchk -r *.MYI (修复所有数据表)
注意：操作第三步前一定要把mysql服务停掉。
4. mysqlcheck -o -r 数据库名称 -p


备份和恢复还原

mysqldump -uroot -p123456 dbname > filename.sql  全库备份








创建跨数据库关联表
use jxdb;
DROP TABLE IF EXISTS jx_messages1;
CREATE TABLE `jx_messages1` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,

  `message_time` varchar(100) DEFAULT NULL,
  `u_id` bigint(20) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `content` varchar(300) DEFAULT NULL,
  `nextparams` varchar(255) DEFAULT NULL,
  `isread` int(11) DEFAULT NULL,

  `type` int(11) DEFAULT NULL COMMENT '0 ',
  
  PRIMARY KEY (`id`)
) ENGINE=FEDERATED   connection = 'mysql://zhangxin:123456@192.168.1.37:3306/jxdb/jx_messages';










